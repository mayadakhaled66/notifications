class AppStrings{
  static const String apiFailureMessage ="Your request is not successful";
}