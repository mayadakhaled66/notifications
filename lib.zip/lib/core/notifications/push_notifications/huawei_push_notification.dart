import 'package:flutter_clean_archticture/core/notifications/notification_data.dart';
import 'package:flutter_clean_archticture/core/notifications/push_notifications/base_push_notification_manager.dart';
import 'package:huawei_push/huawei_push.dart';

class HuaweiNotificationsServices implements BasePushNotificationManager{

  @override
  String getToken(){
    String token = "";
    Push.getTokenStream.listen((value){
      token = value;
    }, onError: (error) {
      print("TokenErrorEvent: " + error.message);
    });
    return token;
  }

  // static Future<RemoteMessage> onReceiveMessage(){
  //
  // }

  @override
  void init() {
    // TODO: implement init
  }

  @override
  void sendPushNotificationRequest({required NotificationData notificationData}) {
    // TODO: implement sendPushNotificationRequest
  }
}