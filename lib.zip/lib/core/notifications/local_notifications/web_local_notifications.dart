import 'package:flutter_clean_archticture/core/notifications/local_notifications/base_local_notifications_manager.dart';
import 'dart:html' as web;
import 'package:flutter_clean_archticture/core/notifications/notification_data.dart';

class WebLocalNotifications implements BaseLocalNotificationManager{

  Future<bool> _checkWebNotificationPermission() async{
    var permission = web.Notification.permission;
    if (permission != 'granted') {
      permission = await web.Notification.requestPermission();
    }
    if (permission == 'granted') {
      return true;
    }else{
      return false;
    }
  }

  @override
  void show({required NotificationData notificationData}) async{
    bool isPermissionGranted = await _checkWebNotificationPermission();
    if(isPermissionGranted){
      web.Notification(notificationData.title,body: notificationData.body);
    }
  }

}